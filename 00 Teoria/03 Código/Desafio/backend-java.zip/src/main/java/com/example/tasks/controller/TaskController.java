package com.example.tasks.controller;

import com.example.tasks.model.Task;
import com.example.tasks.service.TaskService;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class TaskController {
    private TaskService service = new TaskService();

    @GetMapping("/tasks")
    public List<Task> getTasks() throws SQLException {
        return service.getAll();
    }

    @PostMapping("/tasks")
    public Task createTask(@RequestBody Task task) throws SQLException {
        int id = service.add(task);
        task.setId(id);
        return task;
    }

    @PutMapping("/tasks")
    public String updateTask(@RequestBody Task task) throws SQLException {
        service.update(task);
        return "Task updated";
    }

    @DeleteMapping("/tasks/{id}")
    public String deleteTask(@PathVariable int id) throws SQLException {
        service.delete(id);
        return "Task deleted";
    }
}