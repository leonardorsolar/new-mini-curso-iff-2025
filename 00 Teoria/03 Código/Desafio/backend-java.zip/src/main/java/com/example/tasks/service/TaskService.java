package com.example.tasks.service;

import com.example.tasks.model.Task;
import com.example.tasks.repository.TaskRepository;
import java.sql.SQLException;
import java.util.List;

public class TaskService {
    private TaskRepository repository = new TaskRepository();

    public List<Task> getAll() throws SQLException { return repository.getAllTasks(); }
    public int add(Task task) throws SQLException { return repository.addTask(task); }
    public void update(Task task) throws SQLException { repository.updateTask(task); }
    public void delete(int id) throws SQLException { repository.deleteTask(id); }
}