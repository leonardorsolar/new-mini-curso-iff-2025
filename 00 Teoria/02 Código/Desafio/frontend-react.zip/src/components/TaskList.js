import React from 'react';

function TaskList({ tasks, updateTask, deleteTask }) {
  return (
    <ul>
      {tasks.map(task => (
        <li key={task.id} style={{ marginBottom: '10px' }}>
          <input
            type="checkbox"
            checked={task.completed}
            onChange={() => updateTask({ ...task, completed: !task.completed })}
          />
          <span style={{ marginLeft: '10px' }}>{task.title}</span>
          <button style={{ marginLeft: '10px' }} onClick={() => deleteTask(task.id)}>Excluir</button>
        </li>
      ))}
    </ul>
  );
}

export default TaskList;