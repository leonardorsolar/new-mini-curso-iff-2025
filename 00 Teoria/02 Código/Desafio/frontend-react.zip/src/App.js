import React, { useEffect, useState } from 'react';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import taskService from './services/taskService';

function App() {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const data = await taskService.getTasks();
    setTasks(data);
  };

  const addTask = async (title) => {
    await taskService.createTask(title);
    fetchTasks();
  };

  const updateTask = async (task) => {
    await taskService.updateTask(task);
    fetchTasks();
  };

  const deleteTask = async (id) => {
    await taskService.deleteTask(id);
    fetchTasks();
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Gestão de Tarefas</h1>
      <TaskForm addTask={addTask} />
      <TaskList tasks={tasks} updateTask={updateTask} deleteTask={deleteTask} />
    </div>
  );
}

export default App;