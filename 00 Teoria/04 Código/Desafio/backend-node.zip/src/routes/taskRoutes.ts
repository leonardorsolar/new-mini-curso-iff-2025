import { Router } from 'express';
import * as controller from '../controllers/taskController';

const router = Router();

router.get('/tasks', controller.getTasks);
router.post('/tasks', controller.createTask);
router.put('/tasks', controller.updateTask);
router.delete('/tasks/:id', controller.deleteTask);

export default router;