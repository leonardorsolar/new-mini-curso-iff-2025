import express from 'express';
import cors from 'cors';
import taskRoutes from './routes/taskRoutes';
import { createTable } from './repositories/taskRepository';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use('/api', taskRoutes);

createTable().then(() => {
  app.listen(PORT, () => console.log(`Node backend running on http://localhost:${PORT}`));
});