import * as repository from '../repositories/taskRepository';
import { Task } from '../repositories/taskRepository';

export async function getTasks() {
  return repository.getAllTasks();
}

export async function createTask(title: string) {
  const task: Task = { title, completed: false };
  return repository.addTask(task);
}

export async function editTask(task: Task) {
  return repository.updateTask(task);
}

export async function removeTask(id: number) {
  return repository.deleteTask(id);
}