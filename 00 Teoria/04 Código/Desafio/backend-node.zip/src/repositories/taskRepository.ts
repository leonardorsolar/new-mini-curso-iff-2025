import { openDB } from '../db/database';

export interface Task {
  id?: number;
  title: string;
  completed: boolean;
}

export async function createTable() {
  const db = await openDB();
  await db.exec(`
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      completed BOOLEAN NOT NULL DEFAULT 0
    )
  `);
  await db.close();
}

export async function getAllTasks(): Promise<Task[]> {
  const db = await openDB();
  const tasks = await db.all<Task[]>('SELECT * FROM tasks');
  await db.close();
  return tasks;
}

export async function addTask(task: Task) {
  const db = await openDB();
  const result = await db.run(
    'INSERT INTO tasks (title, completed) VALUES (?, ?)',
    task.title,
    task.completed ? 1 : 0
  );
  await db.close();
  return result.lastID;
}

export async function updateTask(task: Task) {
  const db = await openDB();
  await db.run(
    'UPDATE tasks SET title = ?, completed = ? WHERE id = ?',
    task.title,
    task.completed ? 1 : 0,
    task.id
  );
  await db.close();
}

export async function deleteTask(id: number) {
  const db = await openDB();
  await db.run('DELETE FROM tasks WHERE id = ?', id);
  await db.close();
}