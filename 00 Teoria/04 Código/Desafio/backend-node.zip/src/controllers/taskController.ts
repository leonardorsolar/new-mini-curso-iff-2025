import { Request, Response } from 'express';
import * as service from '../services/taskService';

export async function getTasks(req: Request, res: Response) {
  const tasks = await service.getTasks();
  res.json(tasks);
}

export async function createTask(req: Request, res: Response) {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });
  const id = await service.createTask(title);
  res.status(201).json({ id, title, completed: false });
}

export async function updateTask(req: Request, res: Response) {
  const { id, title, completed } = req.body;
  if (!id || !title || completed === undefined) return res.status(400).json({ error: 'Invalid data' });
  await service.editTask({ id, title, completed });
  res.json({ message: 'Task updated' });
}

export async function deleteTask(req: Request, res: Response) {
  const { id } = req.params;
  await service.removeTask(Number(id));
  res.json({ message: 'Task deleted' });
}