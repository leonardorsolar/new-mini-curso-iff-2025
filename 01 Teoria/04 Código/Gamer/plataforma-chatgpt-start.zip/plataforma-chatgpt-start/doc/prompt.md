├── assets
│ ├── platformChar_walk1.png
│ ├── platformChar_walk2.png
│ ├── platformPack_tile013.png
│ └── platformPack_tile043.png
├── index.html
├── p5.js

Crie um jogo usando a bilbioteca p5.
Faça o seguinte:
Use o boneco platformChar_walk1.png (perna fechada) e platformChar_walk2.png(perna aberta) para simular caminhada. O boneco de-se mover pelo teclado para direita esquerda e pular obstáculos
Use o piso repetido no fundo platformPack_tile013.png
Os blocos (platformPack_tile043.png) servem de obstáculos para pular.
Há gravidade e colisão simples
